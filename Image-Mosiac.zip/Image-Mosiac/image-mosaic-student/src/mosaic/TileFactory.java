/*
 * Copyright 2017 Marc Liberatore.
 */

package mosaic;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import images.ImageUtils;

public class TileFactory {
	public final int tileWidth;
	public final int tileHeight;
	private final Map<Integer, List<BufferedImage>> hues;
	
	/**
	 * 
	 * @param colors the palette of RGB colors for this TileFactory
	 * @param tileWidth width (in pixels) for each tile
	 * @param tileHeight height (in pixels) for each tile
	 */
	public TileFactory(int[] colors, int tileWidth, int tileHeight) {
		this.tileWidth = tileWidth;
		this.tileHeight = tileHeight;
		// TODO: when you replace the int[] hues, be sure to replace this code, as well
		hues = new HashMap<Integer, List<BufferedImage>>();
		for (int i = 0; i < colors.length; i++) {
			hues.put(Math.round(ImageUtils.hue(colors[i])), new ArrayList<BufferedImage>());
		}
	}
	
	/**
	 * Returns the distance between two hues on the circle [0,256).
	 * 
	 * @param hue1 
	 * @param hue2
	 * @return the distance between two hues.
	 */
	static int hueDistance(int hue1, int hue2) {
		if(hue1 == 0 && hue2 >= 128) {
			return 256-hue2;
		}
		else if (hue1 == 0 && hue2 <= 128){
			return hue2-hue1;
		}
		else if((hue1 <= 128 && hue2 <= 128) || (hue1 >= 128 && hue2 >= 128)) {
			return Math.abs(hue1 - hue2);
		}
		else if ((hue1 <=128 && hue2 >= 128) || (hue1 >= 128 && hue2 <=128)) {
			if( Math.abs(hue1-hue2) > (256 - Math.abs(hue1 - hue2))) {
				return (256 - Math.abs(hue1 - hue2));
			}
			else {
				return Math.abs(hue1 - hue2);
			}
		}
		return 0;
	}
	
	
	/**
	 * Returns the closest hue from the fixed palette this TileFactory contains.
	 * @param hue
	 * @return the closest hue from the palette
	 */
	Integer closestHue(int hue) {
		int closest = 0;
		int min = 256;
		for (int a: hues.keySet()) {
			if (hueDistance(hue, a) < min) {
				closest = a;
				min = hueDistance(hue, a);
			}
		}
		return closest;
	}
	
	/**
	 * Adds an image to this TileFactory for later use.
	 * @param image the image to add
	 */
	public void addImage(BufferedImage image) {
		image = ImageUtils.resize(image, tileWidth, tileHeight);		
		int avgHue = ImageUtils.averageHue(image);
		
		hues.get(closestHue(avgHue)).add(image);		
	}
	
	/**
	 * Returns the next tile from the list associated with the hue most closely matching the input hue.
	 * 
	 * The returned values should cycle through the list. Each time this method is called, the next 
	 * tile in the list will be returned; when the end of the list is reached, the cycle starts over.
	 *  
	 * @param hue the color to match
	 * @return a tile matching hue
	 */
	public BufferedImage getTile(int hue) {
		// TODO:  return an appropriate image from your map of hues to lists of images; 
		// see assignment description for details
		
		int temp = closestHue(hue);
		BufferedImage image = hues.get(temp).get(0);
		Collections.rotate(hues.get(temp), 2);
		return image;
	}
}
