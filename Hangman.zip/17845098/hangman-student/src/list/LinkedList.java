/*
 * Copyright 2017 Marc Liberatore.
 */

package list;

public class LinkedList<E> {

	private Node<E> head;
	private Node<E> tail;

	public LinkedList() {
		this.head = null;
		this.tail = null;
	}
	
	/**
	 * 
	 * @return the number of elements in this list
	 */
	public int size() {
		return size(head);
	}

	public int size(Node<E> node) {
		if (node == null) {
			return 0;
		}
		else {
			return 1 + size(node.getNext());
		}
	}

	/**
	 * 
	 * @param e the element search for
	 * @return true iff the list contains an element of whose value equals that of e
	 */
	public boolean contains(E e) {
		return contains(e, head);
	}

	public boolean contains(E e, Node<E> node) {
		if (node == null) {
			return false;
		} 
		else if (node.getValue().equals(e)) {
			return true;
		}
		return contains(e, node.getNext());
	}

	/**
	 * Appends the element e to the end of the list.
	 * 
	 * @param e the value to append
	 */
	public void append(E e) {
		Node<E> temp = new Node<E>(e);
		if (head == null) {
			head = temp;
			tail = temp;
		} 
		else {
			tail.setNext(temp);
			tail = tail.getNext();
		}
	}

	@Override
	public String toString() {
		String string = "[";
		if (size() == 1) {
			string = string.concat(head.toString());
		} 
		else if (size() > 0) {
			Node<E> curr = head;
			for (int i = 0; i < size() - 1; i++) {
				string = string.concat(curr + ", ");
				curr = curr.getNext();
			}
			string = string.concat(tail.toString());
		}
		string = string.concat("]");
		return string;
	}
}
