/*
 * Copyright 2017 Marc Liberatore.
 */

package hangman;

import static org.junit.Assert.assertFalse;

import list.LinkedList;

public class LinkedListGameModel implements GameModel {
	private String answer;
	private LinkedList<Character> myGuess;
	public String board = "";

	public LinkedListGameModel(String word) {
		answer = word;
		myGuess = new LinkedList<Character>();
		for (int i = 0; i < answer.length() - 1; i++) {
			board = board.concat("_ ");
		}
		board = board.concat("_");
	}

	
	@Override
	public boolean isPriorGuess(char guess) {
		if (myGuess.contains(guess)) {
			return true;
		}
		else {
			return false;
		}
	}

	
	@Override
	public int numberOfGuesses() {
		return myGuess.size();
	}

	
	@Override
	public boolean isCorrectGuess(char guess) {
		if (!myGuess.contains(guess)) {
			for (char temp : answer.toCharArray()) {
				if (guess == temp) {
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public boolean doMove(char guess) {
		boolean prevMoved = false;
		if (!isPriorGuess(guess)) {
			if (isCorrectGuess(guess)) {
				if (board.length()-1 == 0) {
					board = Character.toString(guess);
				} else if (board.length()-1 > 0) {
					int index = answer.indexOf(guess);
					while (index >= 0) {
						board = board.substring(0, index * 2) + guess + board.substring(index * 2 + 1);
						index = answer.indexOf(guess, index + 1);
					}
				}
				prevMoved = true;
			}
			myGuess.append(guess);
		}
		return prevMoved;
	}

	@Override
	public boolean inWinningState() {
		for (char temp : answer.toCharArray()) {
			if (!myGuess.contains(temp)) {
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean inLosingState() {
		return !inWinningState() && getState() > 9;
	}

	@Override
	public int getState() {
		int correct = 0;
		int wrong = 0;
		String ans = "";
		for (int i = 0; i < answer.length() - 1; i++) {
			if (i == 0) {
				ans = "" + answer.charAt(i);
			} else {
				if (answer.charAt(i) != answer.charAt(i + 1)) {
					ans = ans + answer.charAt(i);
				}
			}
		}
		for (char temp : ans.toCharArray()) {
			if (myGuess.contains(temp)) {
				correct++;
			}
		}
		wrong = numberOfGuesses() - correct;
		return wrong;
	}

	@Override
	public String previousGuessString() {
		return myGuess.toString();
	}

	@Override
	public String toString() {
		return board;
	}

	public String getWord() {
		return answer;
	}
	
}
