/*
 * Copyright 2017 Marc Liberatore.
 */

package scheduler;

import java.util.ArrayList;
import java.util.List;

/**
 * A class representing a student.
 * 
 * @author liberato
 *
 */
public class Student {
	String name;
	int maxCourses;
	List<Course> preferences = new ArrayList<Course>();
	List<Course> schedule = new ArrayList<Course>();
	/**
	 * 
	 * Instantiates a new Student object. The student's maximum course load must be greater
	 * than zero, and the preferences list must contain at least one course.
	 * 
	 * The preference list is copied into this Student object.
	 * 
	 * @param name        the student's name
	 * @param maxCourses  the maximum number of courses that can be on this student's schedule
	 * @param preferences the student's ordered list of preferred courses
	 * @throws IllegalArgumentException thrown if the maxCourses or preferences are invalid
	 */
	public Student(String name, int maxCourses, List<Course> preferences) throws IllegalArgumentException {
		this.name = name;
		this.maxCourses = maxCourses;
		this.preferences = preferences;
		
		if(maxCourses <= 0 || preferences.size() < 1) {
			throw new IllegalArgumentException();
		}
	}
	
	/**
	 * 
	 * @return the student's name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * 
	 * @return the student's max course load
	 */
	public int getMaxCourses() {
		return maxCourses;
	}
	
	/**
	 * Returns the student's list of course preferences, ordered from most- to least-desired.
	 * 
	 * This returned object does not share state with the internal state of the Student.
	 * 
	 * @return the student's preference list
	 */
	public List<Course> getPreferences() {
		List<Course> thing = new ArrayList<Course>();
		for (Course e: preferences)
			thing.add(e);
		return thing;
	}
	
	/**
	 * Returns the student's current schedule.
	 * 
	 * This returned object does not share state with the internal state of the Student.
     *
	 * @return the student's schedule
	 */
	public List<Course> getSchedule() {
		List<Course> thing = new ArrayList<Course>();
		for(Course e : schedule) {
			thing.add(e);
		}
		return thing;
	}

	public void remove(Course course) {
		for(int i = 0; i < schedule.size(); i++) {
			if(schedule.get(i).equals(course)) {
				schedule.remove(i);
				break;
			}
		}
	}
	public void add(Course course) {
		schedule.add(course);
	}
	
	public void noClass() {
		schedule.clear();
	}
}