/*
 * Copyright 2017 Marc Liberatore.
 */

package scheduler;

import java.util.ArrayList;
import java.util.List;

/**
 * A class representing a Course.
 * 
 * @author liberato
 *
 */
public class Course {
	private String courseNumber;
	private int capacity;
	public List<Student> roster = new ArrayList<Student>();
	
	/**
	 * Instantiates a new Course object. The course number must be non-empty, and the 
	 * capacity must be greater than zero.
	 * @param courseNumber a course number, like "COMPSCI190D"
	 * @param capacity     the maximum number of students that can be in the class
	 * @throws IllegalArgumentException thrown if the courseNumber or capacity are invalid
	 */
	public Course(String courseNumber, int capacity) throws IllegalArgumentException {
		if(courseNumber.isEmpty() || capacity <= 0) {
			throw new IllegalArgumentException();
		}
		this.courseNumber = courseNumber;
		this.capacity = capacity;
	}
	
	/**
	 * 
	 * @return the capacity of the course
	 */
	public int getCapacity() {
		return capacity;
	}
	
	/**
	 * 
	 * @return the course number
	 */
	public String getCourseNumber() {
		return courseNumber;
	}

	/**
	 * Returns the list of students enrolled in the course. 
	 * 
	 * This returned object does not share state with the internal state of the Course.
	 * 
	 * @return the list of students currently in the course
	 */
	public List<Student> getRoster() {
		List<Student> thing = new ArrayList<Student>();
		for (Student e : roster) {
			thing.add(e);
		}
		return thing;
	}
	
	public void add(Student student) {
		roster.add(student);
	}

	public void remove(Student student) {
		for(int i = 0; i < roster.size(); i++) {
			if(roster.get(i).equals(student)) {
				roster.remove(i);
			}
		// TODO Auto-generated method stub
		}
	}
}
